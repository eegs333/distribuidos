# Definições de APIs do domínio funcional de Contas Correntes.
Domínio funcional de contas correntes e seus respecitivos recursos.

Recursos Mapeados:
- contas_correntes --> extratos
- contas_correntes --> saldos
- gerentes

A definição desta API está escrita na notação RAML. Para maiores informações sobre a notação RAML (RAML)[http://raml.org/]
Para uma referência aos guias de padrões REST do MBI consulte (MBI Guia Padrão REST)[TBD]
