exec 3>&1 
if [[ $(curl -ksw "%{http_code}" -o >(cat >&3) "https://10.30.67.79:443/jenkins/startBuild?project_name=$1&project_namespace=$2&branch=$3&commit_revision=$4" -m 600) -eq 200 ]]; then exit 0; else exit 1; fi
