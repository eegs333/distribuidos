# Definições de APIs do domínio funcional de Comprovantes.
Domínio funcional de comprovantes e seus respectivos recursos.

Recursos Mapeados:
- comprovantes

A definição desta API está escrita na notação RAML. Para maiores informações sobre a notação RAML (RAML)[http://raml.org/]
Para uma referência aos guias de padrões REST do MBI consulte (MBI Guia Padrão REST)[TBD]
