# Definições de APIs do domínio funcional de Cash Management.
API do Domínio funcional de cash management e seus respecitivos recursos.

## Recursos Mapeados

### boletos_terceiros
Recurso que representa o registro de um documento de boleto.

A definição desta API está escrita na notação RAML. Para maiores informações sobre a notação RAML (RAML)[http://raml.org/]
Para uma referência aos guias de padrões REST do MBI consulte (MBI Guia Padrão REST)[TBD]
